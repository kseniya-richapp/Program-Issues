//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

/*
 1 -> A
 2 -> B
 3 -> C
 ...
 26 -> Z
 27 -> AA
 28 -> AB
 29 -> AC
 30 -> AD
 31,32,33,34 -> AH
 */

func convertToTitle(_ n: Int) -> String {
    var result = ""
    var num = n
    var remain = 0
    var alphabet = Array(" ABCDEFGHIJKLMNOPQRSTUVWXYZ".characters)
    
    while num > 0{
        remain = num % 26
        num = (remain == 0) ? num / 26 - 1 : num / 26
        result = (remain == 0) ? "\(alphabet[26])\(result)" : "\(alphabet[remain])\(result)"
    }
    
    return result
}

let answer = convertToTitle(27)
print(answer)
