//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

/*
 1 -> A
 2 -> B
 3 -> C
 ...
 26 -> Z
 27 -> AA
 28 -> AB
 29 -> AC
 30 -> AD
 31,32,33,34 -> AH
 */
var alphabet = Array(" ABCDEFGHIJKLMNOPQRSTUVWXYZ".characters)

func convertToTitle(_ n: Int) -> String {
    var result = ""
    var num = n
    var remain = 0
    
    while num > 0{
        remain = num % 26
        num = (remain == 0) ? num / 26 - 1 : num / 26
        result = (remain == 0) ? "\(alphabet[26])\(result)" : "\(alphabet[remain])\(result)"
    }
    
    return result
}

let answer = convertToTitle(27)
print(answer)

/*
 A -> 1
 B -> 2
 C -> 3
 ...
 Z -> 26
 AA -> 27
 AB -> 28
 */
func titleToNumber(_ s: String) -> Int {
    var result = 0

    for index in s.characters.indices{
        let char = s.characters[index]
        if let num = alphabet.index(of: char){
            result = result*26 + num
        }
    }
    
    return result
}
