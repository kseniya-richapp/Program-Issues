//: Playground - noun: a place where people can play

import UIKit

func uniq<S : Sequence, T : Hashable>(source: S) -> [T] where S.Iterator.Element == T {
    var buffer = [T]()
    var added = Set<T>()
    for elem in source {
        if !added.contains(elem) {
            buffer.append(elem)
            added.insert(elem)
        }
    }
    return buffer
}

let vals = [1, 4, 2, 2, 6, 24, 15, 2, 60, 15, 6]
let uniqueVals = uniq(source: vals) // [1, 4, 2, 6, 24, 15, 60]
//print(uniqueVals)


func uniq2(source: [Int]) -> [Int]{
    var buffer = [Int]()
    for elem in source {
        if !buffer.contains(elem) {
            buffer.append(elem)
        }
    }
    return buffer
}
let uniqueVals2 = uniq2(source: vals) // [1, 4, 2, 6, 24, 15, 60]
//print(uniqueVals2)

func uniq3(source: inout[Int]){
    var index = 0
    for i in 0..<source.count - 1{
        if(source[i] != source[i+1]){
            source[index] = source[i]
            index += 1
        }
    }
    source[index] = source[source.count - 1]
}

var sourceResult = [1, 2, 2,2, 4, 6, 6,15, 15, 24, 60]
uniq3(source: &sourceResult) // [1, 4, 2, 6, 24, 15, 60]
print(sourceResult)