//: Playground - noun: a place where people can play

import UIKit

func strStr(_ haystack: String, _ needle: String) -> Int {
    //if needle or haystack is empty, return -1
    if(haystack == needle || (needle.isEmpty && haystack.characters.count>0)){
        return 0
    }
    if(haystack.characters.count == 0 || needle.characters.count == 0 || haystack.characters.count < needle.characters.count)
    {
        return -1
    }
    //take first letter in the needle..
    let needleIndex = needle.index(needle.startIndex, offsetBy: 1)
    let firstNeedleLetter = needle.substring(to: needleIndex)
    print(firstNeedleLetter)
    //go through haystack..find first occurence of this letter
    for (i,char) in haystack.characters.enumerated(){
        if(haystack.characters.count - i < needle.characters.count){
            return -1
        }
        if(firstNeedleLetter == "\(char)"){
            print(" char = \(char) - i=\(i)")
            if(parallelTraverse(haystack, needle, foundIndex: i)){
               return i
            }
        }
    }
    return -1
}

func parallelTraverse(_ haystack: String, _ needle: String, foundIndex:Int)->Bool{
    var founIndice = haystack.index(haystack.startIndex, offsetBy: foundIndex)
    //if found traverse in parallel to check the equal..if not..
    for index in needle.characters.indices {
        //print(" haystack[founIndice] = \(haystack[founIndice]) , needle[index]=\(needle[index])")
        if(haystack[founIndice] != needle[index]){
            return false
        }
        founIndice = haystack.index(after: founIndice)
    }
    return true
}

let haystack = ""//"mississippi"
let needle =  ""//"issipi"
//haystack = "aaaaa", needle = "bba"  -1
let answer = strStr(haystack, needle)
print(answer)