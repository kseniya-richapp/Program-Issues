//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
//element that appears more than ⌊ n/2 ⌋ times
func majorityElement(_ nums: [Int]) -> Int {
    var mapDict = [Int:Int]()
    for element in nums{
        if let count = mapDict[element]{
            mapDict[element] = count + 1
        }else{
            mapDict[element] = 1
        }
        if(mapDict[element]! > nums.count/2){
            return element
        }
    }
    
    return 0
}

let res = majorityElement([1,2,3,2,2,3,2,2,4,2]) //10
print(res)