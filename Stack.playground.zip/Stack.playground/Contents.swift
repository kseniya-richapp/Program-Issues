//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

class MinStack {
    /** initialize your data structure here. */
    var arr:[Int]
    var minArr:[Int]
    
    init() {
       arr = [Int]()
       minArr = [Int]()
    }
    
    func push(x:Int) {
        arr.append(x)
        if let last = minArr.last{
            if last < x {
                minArr.append(last)
            }else{
                minArr.append(x)
            }
        }else{
            minArr.append(x)
        }
    }
    
    func pop()->Int {
        var lastElement = 0
        if arr.count > 0{
            if let last = arr.popLast(){
                lastElement = last
            }
        }
        if minArr.count > 0{
            minArr.popLast()
        }
        return lastElement
    }
    
    func top()->Int {
        if let last = arr.last{
            return last
        }
        return 0
    }
    
    func getMin()->Int {
        if let last = minArr.last{
            return last
        }
        return 0
    }
}

let Stack = MinStack()
Stack.push(x: 18)

print(Stack.arr)
print(Stack.minArr)

Stack.push(x: 19)

print(Stack.arr)
print(Stack.minArr)

Stack.push(x: 29)

print(Stack.arr)
print(Stack.minArr)

Stack.push(x: 15)

print(Stack.arr)
print(Stack.minArr)

Stack.push(x: 16)

print(Stack.arr)
print(Stack.minArr)

print(Stack.top())
print(Stack.getMin())
//18, 19, 29, 15 and 16

