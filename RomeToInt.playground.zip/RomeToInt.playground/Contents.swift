//: Playground - noun: a place where people can play

import UIKit

let cc = romanToInt("DCXXI") //MMMMCMXCIX

func romanToInt(_ s: String) -> Int {
    //I=1,IV=4,V=5,IX=9,X=10,IL=40,L=50,XC=90,C=100,CD=400,D=500,CM=900,M=1000
    let charArr = Array(s.characters)
    var number = 0
    var index = 0
    while index<charArr.count {
        let num = intValue(char: charArr[index])
        if(num > 0){
            print("\(num)")
            if((index + 1) < charArr.count){
                let nexNum = intValue(char: charArr[index + 1])
                if(nexNum > num){ //IX or CD
                    number = number + nexNum - num
                    print(" before.. \(number)")
                    index += 1
                }else{
                    number = number + num
                }
            }else{
                number = number + num
            }
            print(" after.. \(number)")
            index += 1
        }else{
            return 0
        }
    }
    return number
}

func intValue(char:Character)->Int{
    var value = 0
    switch(char){
    case "I":
        value = 1
        break
    case "V":
        value = 5
        break
    case "X":
        value = 10
        break
    case "L":
        value = 50
        break
    case "C":
        value = 100
        break
    case "D":
        value = 500
        break
    case "M":
        value = 1000
        break
    default:
        return 0
    }
    return value
}
