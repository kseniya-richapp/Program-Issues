//: Playground - noun: a place where people can play

import UIKit

let intNum = romanToInt("DCXXI") //MMMMCMXCIX
let romanNum = intToRoman(621)
let staticRomanNum = intToRomanSimpleStatic(621)

func intToRomanSimpleStatic(_ num: Int) -> String{
    let M = ["", "M", "MM", "MMM"]
    let C = ["", "C", "CC", "CCC", "CD", "D", "DC", "DCC", "DCCC", "CM"]
    let X = ["", "X", "XX", "XXX", "XL", "L", "LX", "LXX", "LXXX", "XC"]
    let I = ["", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX"]
    let value = M[num/1000] + C[(num%1000)/100] + X[(num%100)/10] + I[num%10]
    return value
}

func intToRoman(_ num: Int) -> String {
    if(num < 1 || num > 3999){
        return "Exceed the integer interval"
    }
    
    
    let values = [1000,900,500,400,100,90,50,40,10,9,5,4,1]
    let strs = ["M","CM","D","CD","C","XC","L","XL","X","IX","V","IV","I"]
    
    var resultStr = ""
    var number = num
    for i in 0..<values.count {
        while(number >= values[i]) {
            number -= values[i]
            resultStr = "\(resultStr)\(strs[i])"
        }
    }
    return resultStr
    //----------------------
    number = num
    resultStr = ""
    while(number>0){
        let remain = number % 10
        let str = stringValue(intNum: remain)
        resultStr = "\(str)\(resultStr)"
        print("str = \(str) and result = \(resultStr)")
        number = number / 10
    }
    return resultStr
    
}

func stringValue(intNum:Int)->String{
    var value:String = ""
    switch(intNum){
    case 1:
        value = "I"
        break
    case 5:
        value = "V"
        break
    case 10:
        value = "X"
        break
    case 50:
        value = "L"
        break
    case 100:
        value = "C"
        break
    case 500:
        value = "D"
        break
    case 1000:
        value = "M"
        break
    default:
        return ""
    }
    return value
}

func romanToInt(_ s: String) -> Int {
    //I=1,IV=4,V=5,IX=9,X=10,IL=40,L=50,XC=90,C=100,CD=400,D=500,CM=900,M=1000
    let charArr = Array(s.characters)
    var number = 0
    var index = 0
    while index<charArr.count {
        let num = intValue(char: charArr[index])
        if(num > 0){
            if((index + 1) < charArr.count){
                let nexNum = intValue(char: charArr[index + 1])
                if(nexNum > num){ //IX or CD
                    number = number + nexNum - num
                    print(" before.. \(number)")
                    index += 1
                }else{
                    number = number + num
                }
            }else{
                number = number + num
            }
            index += 1
        }else{
            return 0
        }
    }
    return number
}

func intValue(char:Character)->Int{
    var value = 0
    switch(char){
    case "I":
        value = 1
        break
    case "V":
        value = 5
        break
    case "X":
        value = 10
        break
    case "L":
        value = 50
        break
    case "C":
        value = 100
        break
    case "D":
        value = 500
        break
    case "M":
        value = 1000
        break
    default:
        return 0
    }
    return value
}
