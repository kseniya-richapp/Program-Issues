//: Playground - noun: a place where people can play

import UIKit

func testFunc(_ nums: [Int], _ target: Int) -> Int{
    var low = 0
    var high = nums.count - 1
    while(low<=high){
        var mid = low + (high - low)/2
        if(nums[mid] == target){
            return mid
        }else if(nums[mid] > target){ //left
            high = mid - 1
        }else{ //right
            low = mid + 1
        }
    }
    return low
}

func searchInsert(_ nums: [Int], _ target: Int) -> Int {
    guard let answer = binarySearch(nums, key: target, range: 0 ..< nums.count) else{
        return nums.count
    }
    return answer
}

func binarySearch<T: Comparable>(_ a: [T], key: T, range: Range<Int>) -> Int? {
    if range.lowerBound >= range.upperBound { // the search key is not present in the array.
        return nil
    } else {
        // Calculate where to split the array.
        let midIndex = range.lowerBound + (range.upperBound - range.lowerBound) / 2
        print(" midIndex = \(midIndex)")
        // Is the search key in the left half?
        if a[midIndex] > key {
            return binarySearch(a, key: key, range: range.lowerBound ..< midIndex)
            // Is the search key in the right half?
        } else if a[midIndex] < key {
            return binarySearch(a, key: key, range: midIndex + 1 ..< range.upperBound)
            // If we get here, then we've found the search key!
        } else {
            return midIndex
        }
    }
}

let nums = [1,3,5,6]
let target = 4
let index = testFunc(nums, target)
print(index)