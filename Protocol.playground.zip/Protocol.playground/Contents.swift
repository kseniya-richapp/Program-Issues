//: Playground - noun: a place where people can play

import UIKit

print(" TEST !! ")

//@objc protocol MyProtocol:class {
//    @objc optional func moreToDo(str:String, pre:String)->String
//    func toDo(x:Int, y:Int)->Int
//}

protocol MyProtocol:class {
    var simpleDescription: String { get }
    func moreToDo(str:String, pre:String)->String
    func toDo(x:Int, y:Int)->Int
}
class DeclareProtocol{
    weak var delegate:MyProtocol?
    
    func calcSumAndMakeString(){
        let sum = delegate?.toDo(x:10, y:5)
        print(sum)
        let fullStr = delegate?.moreToDo(str:"thing", pre:"some")
        print(fullStr)
    }
}

class UseProtocol: MyProtocol{
    var simpleDescription: String = "A very simple class."
    func toDo(x:Int, y:Int)->Int{
        return x + y
    }
    func moreToDo(str:String, pre:String)->String{
        return "\(pre)\(str)"
    }
}

let DeclProClass = DeclareProtocol()
let UsePro = UseProtocol()
DeclProClass.delegate = UsePro
DeclProClass.calcSumAndMakeString()
