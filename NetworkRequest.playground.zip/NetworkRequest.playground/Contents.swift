//: Playground - noun: a place where people can play

import UIKit

struct Course{
    let id: Int
    let name: String
    let link: String
    let imageURL: String
    
    init(json:[String:Any]){
        id = json["id"] as? Int ?? 0
        name = json["name"] as? String ?? ""
        link = json["link"] as? String ?? ""
        imageURL = json["imageURL"] as? String ?? ""
    }
}

func makeNetworkRequest(){
    
    let urlRequest = "https://api.letsbuildthatapp.com/jsondecodable/course"
    guard let url = URL(string: urlRequest) else{ return }
    URLSession.shared.dataTask(with: url) { (data, response, error) in
        print(" HERE !")
        guard let data = data else {return}
        do{
            guard let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String:Any] else {return}
            let course = Course(json: json)
            print(course)
        }catch let jsonErr{
            print(jsonErr)
        }
    }.resume()
    
}

makeNetworkRequest()
