//: Playground - noun: a place where people can play

import UIKit

func countAndSay(_ n: Int) -> String {
    var arrToSay:[Int:String] = [1: "1", 2: "11"]
    if(n == 1 || n == 2){
        return arrToSay[1]!
    }
    var sequenceString = ""
    for i in 2..<n{
        var digitCount = 1
        guard let secondSeq = arrToSay[i] else {return ""}
        for index in secondSeq.characters.indices{
            let thisChar = secondSeq[index]
            if(index == secondSeq.startIndex){//first digit in the sequence so lets count it!
                digitCount = 1
            }else{
                let beforeChar = secondSeq[secondSeq.index(before: index)]
                guard let beforeRealInt = Int("\(beforeChar)") else { return "" }
                if(thisChar == beforeChar){ //same digit as before, need to count them
                    digitCount += 1
                    if(secondSeq.index(after: index) == secondSeq.endIndex){ //last digit in sequance!
                        sequenceString = sequenceString + "\(digitCount)\(thisChar)"
                    }
                }else {//another digit, need to say what is the number itself is
                    //check if this is the last digit
                    sequenceString = (secondSeq.index(after: index) == secondSeq.endIndex) ? "\(sequenceString)\(digitCount)\(beforeRealInt)1\(thisChar)" : "\(sequenceString)\(digitCount)\(beforeRealInt)"
                    digitCount = 1
                }
            }
        }
        arrToSay[i + 1] = sequenceString
        sequenceString = ""
    }
    //print(arrToSay)
    return arrToSay[arrToSay.count]!
}

let result = countAndSay(7) //5 = 111221 4 = 1211 6 = 312211 7=13112221 8=1113213211
print(result)