//: Playground - noun: a place where people can play

import UIKit

let num = reverse(1563847412) //321; 1534236469(0)  -2147483648(0), 1563847412 (0)

func reverse(_ x: Int) -> Int {
    var num = x
   // pow(2,31) = signed=2147483648, unsigned=pow(2,32)=4294967296
    print(pow(2,31))
    var inverseSum = 0
    while( num != 0 ){
        let remain = num % 10
        inverseSum = inverseSum*10 + remain
        num = num / 10
        print("remain = \(remain) inverseSum = \(inverseSum) num = \(num)")
        if(inverseSum > 2147483648 || inverseSum < -2147483648){
            return 0
        }
    }
    return inverseSum
}