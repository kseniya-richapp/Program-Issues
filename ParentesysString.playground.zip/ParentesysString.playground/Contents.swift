//: Playground - noun: a place where people can play

import UIKit

public struct Stack<T> {
    fileprivate var array = [T]()
    
    public var isEmpty: Bool {
        return array.isEmpty
    }
    
    public var count: Int {
        return array.count
    }
    
    public mutating func push(_ element: T) {
        array.append(element)
    }
    
    public mutating func pop() -> T? {
        return array.popLast()
    }
    
    public var top: T? {
        return array.last
    }
}

extension String {
    
    subscript (i: Int) -> Character {
        return self[index(startIndex, offsetBy: i)]
    }
}

let leftParentheses = ["(","{","["]
let rightParentheses = [")","}","]"]

func isValid(_ s: String) -> Bool {
    var strStack:Stack<String> = Stack()
    for i in 0..<s.characters.count{
        let oneStr = "\(s[i])"
        if(leftParentheses.contains(oneStr)){ //left stack
            strStack.push(oneStr)
            print(strStack)
        }else if(rightParentheses.contains(oneStr)){//right stack
            if( strStack.isEmpty ){
                return false
            }
            guard let last = strStack.pop() else {return false}
            if(!checkParanthInLeftArr(popStr:last, input:oneStr)){
                return false
            }
            print(strStack)
        }
    }
    print(strStack)
    if( !strStack.isEmpty ){
        return false
    }
    return true
}

func checkParanthInLeftArr(popStr:String, input:String)->Bool{
    guard leftParentheses.contains(popStr) else {
        return false
    }
    guard let index = leftParentheses.index(of: popStr) else {return false}
    print(" our check index=\(index)input=\(input) popStr=\(popStr) inRight = \(rightParentheses[index])")
    if(rightParentheses[index] == input){
        return true
    }
    return false
}

let answer = isValid("[")