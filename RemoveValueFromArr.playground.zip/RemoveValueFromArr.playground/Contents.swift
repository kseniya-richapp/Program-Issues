//: Playground - noun: a place where people can play

import UIKit

var arr = [3,2,2,3]

func removeElement(_ nums: inout [Int], _ val: Int) -> Int {
    let n = nums.count
    if(n==0){
        return 0
    }
    var i = 0
    for j in 0..<n {
        if(nums[j] != val)
        {
            nums[i]=nums[j]
            print("nums[i]= \(nums[i]), nums[j]=\(nums[j])")
            i += 1
        }
    }
    if(i<n){
        for k in i..<n{
            print("nums= \(nums), k=\(k)")
            //nums.remove(at: k)
        }
    }
    return i
}

let res1 = removeElement(&arr, 3)
print(res1)
print(arr)
//
//func removeElement(_ nums: inout [Int], _ val: Int) -> Int {
//    var foundIndex = 0
//    var n = nums.count
//    for i in 0..<n {
//        if (nums[i] == val) {
//            foundIndex = i
//            print("foundIndex = \(foundIndex)")
//            break
//        }
//    }
//    if (foundIndex < n)
//    {
//        n = n - 1
//        for j in foundIndex..<n{
//            print("nums[j]= \(nums[j]), nums[j+1]=\(nums[j+1])")
//            nums[j] = nums[j+1]
//        }
//    }
//    return n
//}
//var arr1 = [1,2,3,4,3,6,3,7]
//let res = removeElement(&arr1, 3)
//print(res)
//print(arr1)


