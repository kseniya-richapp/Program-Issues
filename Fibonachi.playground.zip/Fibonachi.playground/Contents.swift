//: Playground - noun: a place where people can play

import UIKit

func fiboNachi(_ n:Int)->Int{
    if(n<=2){
        return 1
    }else{
        return fiboNachi(n-1) + fiboNachi(n-2)
    }
}
//1	1	2	3	5	8	13
let answer = fiboNachi(6) //3+2 = 5
//print(answer)

func fibonachiIterate(_ n:Int)->Int{
    var num1 = 0
    var num2 = 1
    for _ in 0..<n{
        let num = num1 + num2
        num1 = num2
        num2 = num
    }
    return num1
}

let answerIt = fibonachiIterate(6) //3+2 = 5
print(answerIt)