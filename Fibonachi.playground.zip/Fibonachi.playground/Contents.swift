//: Playground - noun: a place where people can play

import UIKit

func fiboNachi(_ n:Int)->Int{
    if(n<=2){
        return 1
    }else{
        return fiboNachi(n-1) + fiboNachi(n-2)
    }
}
//1	1	2	3	5	8	13
let answer = fiboNachi(6) //3+2 = 5
print(answer)

