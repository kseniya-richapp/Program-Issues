//: Playground - noun: a place where people can play

import UIKit

public class ListNode {
    public var val: Int
    public var next: ListNode?
    public init(_ val: Int) {
        self.val = val
        self.next = nil
    }
}

func mergeTwoLists(_ l1: ListNode?, _ l2: ListNode?) -> ListNode? {
    
    guard let list1 = l1 else { return l2 }
    guard let list2 = l2 else { return l1 }
    let v1 = list1.val
    let v2 = list2.val
    let next1 = list1.next
    let next2 = list2.next
    if v1 < v2 {
        let newMergedList = self.mergeTwoLists(next1, l2)
        list1.next = newMergedList
        return list1
    } else {
        let newMergedList = self.mergeTwoLists(l1, next2)
        list2.next = newMergedList
        return list2
    }
}

let L4_1 = ListNode(4)
let L4_2 = ListNode(4)
let L3 = ListNode(3)
let L2 = ListNode(2)
let L1_1 = ListNode(1)
let L1_2 = ListNode(1)
L1_1.next = L2
L2.next = L4_1

L1_2.next = L3
L3.next = L4_2
let s = Solution()
let merged = s.mergeTwoLists( L1_1, L1_2)