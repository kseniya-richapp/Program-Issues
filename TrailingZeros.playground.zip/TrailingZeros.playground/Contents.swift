//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

func trailingZeroes(_ n: Int) -> Int {
    var result = 0
    var i = 5
    while n/i >= 1{
        result += n/i
        i *= 5
    }
    return result
}

let res = trailingZeroes(3)
print(res)
