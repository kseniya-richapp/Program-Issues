//: Playground - noun: a place where people can play

import UIKit

let is_palindrome = isPalindrome(11211)

func isPalindrome(_ x: Int) -> Bool {
    if(x < 0 || (x % 10 == 0 && x != 0) ){//all negatives are not palindrome
        return false
    }else if(x < 10){
        return true
    }
    var secondHalf = 0
    var number = x
    while(secondHalf < number){
        let suff = number % 10 //ostatok 1
        number = number / 10 //47
        secondHalf = secondHalf*10 + suff //47*10 + 1 = 471
        print("\(number) \(secondHalf) \(suff)")
    }
    print("\(number) \(secondHalf)")
    if(number == secondHalf || number == secondHalf/10 ){ //47 == ?? 471, so divide to 10
        return true
    }

    return false
}

func notGoodTime(_ x: Int) -> Bool{
    if(x < 0){//all negatives are not palindrome
        return false
    }else if(x == 0){
        return true
    }
    
    let arr_characters = arrayOfCharacters(num: x)
    if(x < 0){
        return false
    }else if(x == 0){
        return true
    }
    var i = arr_characters.count
    if(i > 1){
        for char in arr_characters{
            if(char != arr_characters[i-1]){
                return false
            }
            i -= 1
            if(i < 2){
                return true
            }
        }
    }else if(i == 1){
        return true
    }
    return false
}

func arrayOfCharacters(num:Int)->[Int] {
    return String(num).characters.flatMap { Int(String($0))  }
}
