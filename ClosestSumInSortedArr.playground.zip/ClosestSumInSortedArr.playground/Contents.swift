//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

/*
 Input: arr[] = {10, 22, 28, 29, 30, 40}, x = 54
 Output: 22 and 30
 
 Input: arr[] = {1, 3, 4, 7, 10}, x = 15
 Output: 4 and 10
 */

func twoSumDiffer(_ numbers: [Int], _ target: Int) -> [Int] {
    var result = [Int]()
    var l = 0
    var r = numbers.count - 1
    var diff = 2147483647
    var res_l = l
    var res_r = r
    
    while(l < r){
        
        if( (numbers[l] + numbers[r] - target ) < diff) {
            diff = abs(numbers[l] + numbers[r] - target)
            res_l = l
            res_r = r
        }
        
        if(numbers[l] + numbers[r] < target){
            l += 1
        }else{
            r -= 1
        }
        
    }
    result.append(numbers[res_l])
    result.append(numbers[res_r])
    
    return result
}

let arr = [10, 22, 28, 29, 30, 40]
let x = 54
let answer = twoSumDiffer(arr,x)
print(answer)



func twoSum2(_ numbers: [Int], _ target: Int) -> [Int] {
    var result = [Int]()
    var l = 0
    var r = numbers.count - 1
    var diff = 2147483647
    var res_l = l
    var res_r = r
    
    while(l < r){
        
        if( numbers[l] + numbers[r] == target) {
            res_l = l
            res_r = r
        }
        
        if(numbers[l] + numbers[r] < target){
            l += 1
        }else{
            r -= 1
        }
        
    }
    result.append(res_l + 1)
    result.append(res_r + 1)
    
    return result
}

let arr1 = [2, 7, 11, 15]
let x1 = 9
let answer1 = twoSum2(arr1,x1)
print(answer1)